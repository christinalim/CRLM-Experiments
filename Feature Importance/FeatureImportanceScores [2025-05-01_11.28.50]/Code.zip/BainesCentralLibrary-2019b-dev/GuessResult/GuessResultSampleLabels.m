classdef (Abstract) GuessResultSampleLabels < MatrixContainer
    %GuessResultSampleLabels
    %
    % TODO
    
    % Primary Author: David DeVries
    % Created: June 11, 2020
    
    
    % *********************************************************************   ORDERING: 1 Abstract        X.1 Public       X.X.1 Not Constant
    % *                            PROPERTIES                             *             2 Not Abstract -> X.2 Protected -> X.X.2 Constant
    % *********************************************************************                               X.3 Private
                       
    properties (Access = private, Constant = true)
    end
    
    
    
    % *********************************************************************   ORDERING: 1 Abstract     -> X.1 Not Static 
    % *                          PUBLIC METHODS                           *             2 Not Abstract    X.2 Static
    % *********************************************************************
        
    methods (Access = public, Abstract)
        
        PrintHeaders(obj)
        
        PrintRowForSample(obj, dSampleIndex)
        
        MustBeValidSampleLabelsForGuessResult(oGuessResultSampleLabels, oGroundTruthSampleLabels)

    end
    
    methods (Access = public, Static = false)
        
        function obj = GuessResultSampleLabels(m2xLabels)
            %obj = GuessResultSampleLabels(m2xLabels)
            %
            % SYNTAX:
            %  obj = GuessResultSampleLabels(m2xLabels)
            %
            % DESCRIPTION:
            %  Constructor for GuessResultSampleLabels
            %
            % INPUT ARGUMENTS:
            %  TODO
            %
            % OUTPUTS ARGUMENTS:
            %  obj: Constructed object
                        
            % super-class constructor
            obj@MatrixContainer(m2xLabels)
        end      
        
        
        % >>>>>>>>>>>>>>>>>>>> GETTERS <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        function dNumSamples = GetNumberOfSamples(obj)
            %dNumSamples = GetNumberOfSamples(obj)
            %
            % SYNTAX:
            %  dNumSamples = obj.GetNumberOfSamples()
            %
            % DESCRIPTION:
            %  Returns the number of samples for which there are guess
            %  results
            %  (e.g. the number of rows in stored in the matrix)
            %
            % INPUT ARGUMENTS:
            %  obj: GuessResultSampleLabels obj
            %
            % OUTPUTS ARGUMENTS:
            %  TODO
            
            dNumSamples = size(obj, 1);
        end
        
        function dNumClasses = GetNumberOfClasses(obj)
            %dNumClasses = GetNumberOfClasses(obj)
            %
            % SYNTAX:
            %  dNumClasses = GetNumberOfClasses(obj)
            %
            % DESCRIPTION:
            %  Returns the number of classes for which there are guess
            %  results
            %  (e.g. the number of columns stored in the matrix)
            %
            % INPUT ARGUMENTS:
            %  obj: GuessResultSampleLabels obj
            %
            % OUTPUTS ARGUMENTS:
            %  TODO
            
            dNumClasses = size(obj, 2);
        end
        
        % >>>>>>>>>>>>>>>>>>>>>>> OVERLOADED <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        function disp(obj)
            %disp(obj)
            %
            % SYNTAX:
            %  disp(obj)
            %
            % DESCRIPTION:
            %  Displays a GuessResultSampleLabels collection as columns of
            %  confidences for each class.
            %
            % INPUT ARGUMENTS:
            %  obj: GuessResultSampleLabels object
            %
            % OUTPUTS ARGUMENTS:
            %  None
            
            % Headers
            obj.PrintHeaders();
            
            fprintf(newline);
            
            % Print row by row
            for dSampleIndex=1:obj.GetNumberOfSamples()
                obj.PrintRowForSample(dSampleIndex);
                
                fprintf(newline);
            end     
            
            % Footer
            fprintf(newline);
            fprintf('Classes:'); 
            fprintf(newline);
            
            obj.PrintClassesFooter();
        end
        
    end
    
    methods (Access = public, Static = true)       
    end
    
    
    
    % *********************************************************************   ORDERING: 1 Abstract     -> X.1 Not Static 
    % *                        PROTECTED METHODS                          *             2 Not Abstract    X.2 Static
    % *********************************************************************
    
    methods (Access = protected, Abstract)
    end
    
    
    methods (Access = protected, Static = false)    
    end
    
    
    methods (Access = protected, Static = true)      
    end
    
    
    
    % *********************************************************************   ORDERING: 1 Abstract     -> X.1 Not Static
    % *                         PRIVATE METHODS                           *             2 Not Abstract    X.2 Static
    % *********************************************************************
    
    methods (Access = private, Abstract)
    end
    
    
    methods (Access = private, Static = false)       
    end
    
    
    methods (Access = private, Static = true)      
    end
    
    
    
    % <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    % <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    
    
    % *********************************************************************
    % *                        UNIT TEST ACCESS                           *
    % *                  (To ONLY be called by tests)                     *
    % *********************************************************************
    
    methods (Access = {?matlab.unittest.TestCase}, Static = false)        
    end
    
    
    methods (Access = {?matlab.unittest.TestCase}, Static = true)        
    end
end

